# CortexOS Skill Bundle: database

**Built:** 2026-03-20 18:51 UTC
**Skills:** 7

## Installation

```bash
tar xzf database.tar.gz
cd database
sudo bash install.sh
```

## Contents
- postgres
- mysql
- redis
- mongodb
- elasticsearch
- cassandra
- sqlite
