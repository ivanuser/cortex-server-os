#!/bin/bash
# CortexOS Offline Skill Installer
# Usage: sudo bash install.sh [--dest /path/to/skills]

set -euo pipefail

DEST="${1:-/var/lib/cortexos/skills}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_SRC="$SCRIPT_DIR/skills"

GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}CortexOS Offline Skill Installer${NC}"
echo "Installing to: $DEST"
echo "─────────────────────────────────"

# Create destination
mkdir -p "$DEST"

if [ ! -d "$SKILL_SRC" ]; then
  echo "Error: No skills directory found in bundle"
  exit 1
fi

count=0
for skill_dir in "$SKILL_SRC"/*/; do
  [ -d "$skill_dir" ] || continue
  skill_name="$(basename "$skill_dir")"
  echo -e "  ${GREEN}✓${NC} Installing $skill_name"
  cp -r "$skill_dir" "$DEST/"
  ((count++))
done

echo "─────────────────────────────────"
echo -e "${GREEN}✅ Installed $count skills to $DEST${NC}"

# Update manifest if cortexos-skill exists
if command -v cortexos-skill &>/dev/null; then
  echo "Updating skill manifest..."
  cortexos-skill refresh 2>/dev/null || true
fi
