# CortexOS Skill Bundle: web-server

**Built:** 2026-03-20 18:51 UTC
**Skills:** 5

## Installation

```bash
tar xzf web-server.tar.gz
cd web-server
sudo bash install.sh
```

## Contents
- nginx
- apache
- caddy
- haproxy
- certbot
