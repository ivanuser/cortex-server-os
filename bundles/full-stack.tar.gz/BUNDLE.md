# CortexOS Skill Bundle: full-stack

**Built:** 2026-03-20 18:51 UTC
**Skills:** 46

## Installation

```bash
tar xzf full-stack.tar.gz
cd full-stack
sudo bash install.sh
```

## Contents
- ansible
- apache
- aws-cli
- azure-cli
- backup-manager
- caddy
- cassandra
- certbot
- cloudflare-install
- cloudflare-ops
- discourse
- docker-compose
- docker-manager
- elasticsearch
- firewall-manager
- gcloud
- gitlab-runner
- golang
- grafana
- haproxy
- java
- jenkins
- kubernetes
- memcached
- mongodb
- monitoring
- mysql
- network-manager
- nextcloud
- nginx
- nodejs
- package-manager
- postgres
- prometheus
- python
- rabbitmq
- redis
- rust
- security-hardening
- server-monitor
- sqlite
- storage-manager
- systemd-manager
- terraform
- user-manager
- wireguard
